interface MetricCardProps {
  label: string;
  value: string | number;
  variant?: "blue" | "green" | "red" | "amber";
}

export function MetricCard({ label, value, variant = "blue" }: MetricCardProps) {
  const backgrounds = {
    blue: "bg-[#E6F1FB]",
    green: "bg-[#EAF3DE]",
    red: "bg-[#FCEBEB]",
    amber: "bg-[#FAEEDA]",
  };

  const textColors = {
    blue: "text-[#185FA5]",
    green: "text-[#2d5016]",
    red: "text-[#8b1538]",
    amber: "text-[#8b6914]",
  };

  return (
    <div className={`${backgrounds[variant]} rounded-lg p-3 flex flex-col gap-1`}>
      <div className={`text-[10px] uppercase tracking-wide ${textColors[variant]} opacity-70`}>
        {label}
      </div>
      <div className={`text-2xl font-semibold ${textColors[variant]}`}>
        {value}
      </div>
    </div>
  );
}
