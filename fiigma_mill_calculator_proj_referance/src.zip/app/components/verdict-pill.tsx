interface VerdictPillProps {
  text: string;
  variant?: "excellent" | "average" | "poor" | "on-target";
}

export function VerdictPill({ text, variant = "average" }: VerdictPillProps) {
  const styles = {
    excellent: "bg-[#EAF3DE] text-[#2d5016] border-[#2d5016]",
    average: "bg-[#FAEEDA] text-[#8b6914] border-[#8b6914]",
    poor: "bg-[#FCEBEB] text-[#8b1538] border-[#8b1538]",
    "on-target": "bg-[#EAF3DE] text-[#2d5016] border-[#2d5016]",
  };

  return (
    <div className={`inline-flex items-center px-3 py-1.5 rounded-full border ${styles[variant]} text-xs font-medium`}>
      {text}
    </div>
  );
}
