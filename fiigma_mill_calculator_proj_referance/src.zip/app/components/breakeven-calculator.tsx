import { useState } from "react";
import { InputField } from "./input-field";
import { MetricCard } from "./metric-card";
import { VerdictPill } from "./verdict-pill";
import { CTAButton } from "./cta-button";
import { SectionLabel } from "./section-label";

export function BreakevenCalculator() {
  const [scrapPrice, setScrapPrice] = useState("32");
  const [spongePrice, setSpongePrice] = useState("28");
  const [scrapPercent, setScrapPercent] = useState("70");
  const [powerRate, setPowerRate] = useState("6");
  const [unitsPerTonne, setUnitsPerTonne] = useState("450");
  const [labourOverhead, setLabourOverhead] = useState("1500");
  const [rollingOther, setRollingOther] = useState("800");
  const [yieldPercent, setYieldPercent] = useState("92");
  const [product, setProduct] = useState("TMT 12mm");
  const [sellingPrice, setSellingPrice] = useState("48");
  const [customMargin, setCustomMargin] = useState("2000");

  // Calculations
  const scrapPct = parseFloat(scrapPercent) / 100;
  const spongePct = 1 - scrapPct;
  const rmCost = (parseFloat(scrapPrice) * scrapPct + parseFloat(spongePrice) * spongePct) * 1000;
  const powerCost = parseFloat(powerRate) * parseFloat(unitsPerTonne);
  const labourCost = parseFloat(labourOverhead);
  const rollingCost = parseFloat(rollingOther);
  const totalCostPerTonne = rmCost + powerCost + labourCost + rollingCost;
  const yieldFactor = parseFloat(yieldPercent) / 100;
  const costPerKg = totalCostPerTonne / 1000 / yieldFactor;
  
  const floorPrice = costPerKg.toFixed(2);
  const safePrice = (costPerKg * 1.05).toFixed(2);
  const goodPrice = (costPerKg * 1.10).toFixed(2);
  const quotePrice = (costPerKg + parseFloat(customMargin) / 1000).toFixed(2);

  const margin = parseFloat(sellingPrice) - costPerKg;
  const marginPercent = (margin / costPerKg * 100).toFixed(1);

  const getVerdictVariant = () => {
    const marginPct = parseFloat(marginPercent);
    if (marginPct >= 10) return "excellent";
    if (marginPct >= 5) return "average";
    return "poor";
  };

  const getVerdictText = () => {
    const marginPct = parseFloat(marginPercent);
    if (marginPct >= 10) return "Excellent margin";
    if (marginPct >= 5) return "Acceptable margin";
    return "Risky margin";
  };

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-xl font-semibold">Scrap to TMT — breakeven</h1>
        <p className="text-sm text-gray-400">Know your floor price before you quote</p>
      </div>

      {/* Raw Material Section */}
      <div>
        <SectionLabel text="Raw Material" />
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <InputField
              label="Scrap"
              value={scrapPrice}
              onChange={setScrapPrice}
              placeholder="32"
              suffix="₹/kg"
            />
            <InputField
              label="Sponge iron"
              value={spongePrice}
              onChange={setSpongePrice}
              placeholder="28"
              suffix="₹/kg"
            />
          </div>
          <InputField
            label="Scrap % in mix"
            value={scrapPercent}
            onChange={setScrapPercent}
            placeholder="70"
            suffix="%"
          />
        </div>
      </div>

      {/* Production Costs Section */}
      <div>
        <SectionLabel text="Production Costs" />
        <div className="grid grid-cols-2 gap-3">
          <InputField
            label="Power rate"
            value={powerRate}
            onChange={setPowerRate}
            placeholder="6"
            suffix="₹/unit"
          />
          <InputField
            label="Units per tonne"
            value={unitsPerTonne}
            onChange={setUnitsPerTonne}
            placeholder="450"
          />
          <InputField
            label="Labour + overhead"
            value={labourOverhead}
            onChange={setLabourOverhead}
            placeholder="1500"
            suffix="₹/t"
          />
          <InputField
            label="Rolling + other"
            value={rollingOther}
            onChange={setRollingOther}
            placeholder="800"
            suffix="₹/t"
          />
        </div>
      </div>

      {/* Yield & Selling Price Section */}
      <div>
        <SectionLabel text="Yield & Selling Price" />
        <div className="space-y-3">
          <InputField
            label="Yield"
            value={yieldPercent}
            onChange={setYieldPercent}
            placeholder="92"
            suffix="%"
          />
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1.5">
              <label className="text-[10px] uppercase tracking-wide text-gray-400">
                Product
              </label>
              <select
                value={product}
                onChange={(e) => setProduct(e.target.value)}
                className="w-full h-10 px-3 bg-[#2a2a2a] border border-gray-700 rounded-lg text-white outline-none focus:border-[#185FA5]"
              >
                <option>TMT 10mm</option>
                <option>TMT 12mm</option>
                <option>TMT 16mm</option>
                <option>TMT 20mm</option>
              </select>
            </div>
            <InputField
              label="Selling price"
              value={sellingPrice}
              onChange={setSellingPrice}
              placeholder="48"
              suffix="₹/kg"
            />
          </div>
        </div>
      </div>

      {/* Divider */}
      <div className="border-t border-gray-700"></div>

      {/* Pricing Cards */}
      <div className="grid grid-cols-3 gap-2">
        <div className="bg-[#FCEBEB] rounded-lg p-3 flex flex-col items-center gap-1">
          <div className="text-[10px] uppercase tracking-wide text-[#8b1538] opacity-70">Floor</div>
          <div className="text-lg font-semibold text-[#8b1538]">₹{floorPrice}</div>
          <div className="text-[9px] text-[#8b1538] opacity-70">/kg</div>
        </div>
        <div className="bg-[#FAEEDA] rounded-lg p-3 flex flex-col items-center gap-1">
          <div className="text-[10px] uppercase tracking-wide text-[#8b6914] opacity-70">Safe</div>
          <div className="text-lg font-semibold text-[#8b6914]">₹{safePrice}</div>
          <div className="text-[9px] text-[#8b6914] opacity-70">/kg</div>
        </div>
        <div className="bg-[#EAF3DE] rounded-lg p-3 flex flex-col items-center gap-1">
          <div className="text-[10px] uppercase tracking-wide text-[#2d5016] opacity-70">Good</div>
          <div className="text-lg font-semibold text-[#2d5016]">₹{goodPrice}</div>
          <div className="text-[9px] text-[#2d5016] opacity-70">/kg</div>
        </div>
      </div>

      {/* Custom Margin Calculator */}
      <div className="bg-[#2a2a2a] rounded-lg p-4 space-y-2">
        <div className="text-sm text-gray-400">I want</div>
        <div className="flex items-center gap-2">
          <span className="text-white">₹</span>
          <input
            type="text"
            value={customMargin}
            onChange={(e) => setCustomMargin(e.target.value)}
            className="flex-1 h-8 px-2 bg-[#1a1a1a] border border-gray-700 rounded text-white outline-none focus:border-[#185FA5]"
          />
          <span className="text-gray-400">/tonne</span>
        </div>
        <div className="text-sm">
          <span className="text-gray-400">→ quote </span>
          <span className="text-[#185FA5] font-semibold">₹{quotePrice}/kg</span>
        </div>
      </div>

      {/* Cost Breakdown Table */}
      <div className="bg-[#2a2a2a] rounded-lg overflow-hidden">
        <div className="flex justify-between px-4 py-2 border-b border-gray-700">
          <span className="text-sm text-gray-400">Raw material</span>
          <span className="text-sm text-white">₹{(rmCost / 1000).toFixed(2)}/kg</span>
        </div>
        <div className="flex justify-between px-4 py-2 border-b border-gray-700">
          <span className="text-sm text-gray-400">Power cost</span>
          <span className="text-sm text-white">₹{(powerCost / 1000).toFixed(2)}/kg</span>
        </div>
        <div className="flex justify-between px-4 py-2 border-b border-gray-700">
          <span className="text-sm text-gray-400">Labour + overhead</span>
          <span className="text-sm text-white">₹{(labourCost / 1000).toFixed(2)}/kg</span>
        </div>
        <div className="flex justify-between px-4 py-2 border-b border-gray-700">
          <span className="text-sm text-gray-400">Rolling + other</span>
          <span className="text-sm text-white">₹{(rollingCost / 1000).toFixed(2)}/kg</span>
        </div>
        <div className="flex justify-between px-4 py-2 bg-gray-800">
          <span className="text-sm font-semibold text-white">Total cost (@ {yieldPercent}% yield)</span>
          <span className="text-sm font-semibold text-white">₹{floorPrice}/kg</span>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 gap-3">
        <MetricCard label="Current margin" value={`₹${margin.toFixed(2)}/kg`} variant={margin > 0 ? "green" : "red"} />
        <MetricCard label="Margin %" value={`${marginPercent}%`} variant={parseFloat(marginPercent) > 5 ? "green" : "red"} />
      </div>

      {/* Verdict */}
      <div className="space-y-2">
        <VerdictPill text={getVerdictText()} variant={getVerdictVariant()} />
        <p className="text-sm text-gray-400">
          {parseFloat(marginPercent) >= 10
            ? "Strong margins. You have good pricing power."
            : parseFloat(marginPercent) >= 5
            ? "Margins are acceptable but watch your costs."
            : "Margins are tight. Consider repricing or reducing costs."}
        </p>
      </div>

      {/* CTA Buttons */}
      <div className="space-y-3">
        <CTAButton text="Export cost sheet" onClick={() => alert("Exporting cost sheet...")} />
        <CTAButton text="Compare with last month" onClick={() => alert("Opening comparison...")} />
      </div>
    </div>
  );
}
