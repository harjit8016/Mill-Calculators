interface SectionLabelProps {
  text: string;
}

export function SectionLabel({ text }: SectionLabelProps) {
  return (
    <div className="text-[10px] uppercase tracking-widest text-gray-500 mb-3">
      {text}
    </div>
  );
}
