import { Outlet, Link, useLocation } from "react-router";
import { BarChart3, Target, Zap } from "lucide-react";

export function Layout() {
  const location = useLocation();

  const tabs = [
    { path: "/", icon: BarChart3, label: "Yield" },
    { path: "/breakeven", icon: Target, label: "Breakeven" },
    { path: "/power", icon: Zap, label: "Power" },
  ];

  return (
    <div className="h-screen flex flex-col bg-[#1a1a1a] text-white max-w-[390px] mx-auto">
      {/* Status bar */}
      <div className="h-6 bg-[#0f0f0f] flex items-center justify-center">
        <div className="text-[11px] text-gray-400">9:41 AM</div>
      </div>

      {/* Content area */}
      <div className="flex-1 overflow-y-auto pb-[60px]">
        <Outlet />
      </div>

      {/* Bottom tab bar */}
      <div className="fixed bottom-0 left-0 right-0 max-w-[390px] mx-auto h-[60px] bg-[#1a1a1a] border-t border-gray-700 flex items-center justify-around pb-safe">
        {tabs.map((tab) => {
          const isActive = location.pathname === tab.path;
          const Icon = tab.icon;
          
          return (
            <Link
              key={tab.path}
              to={tab.path}
              className="flex flex-col items-center justify-center gap-1 flex-1 h-full"
            >
              <Icon 
                className={`w-6 h-6 ${
                  isActive ? "text-[#185FA5]" : "text-gray-500"
                }`}
              />
              <span 
                className={`text-[10px] ${
                  isActive ? "text-[#185FA5]" : "text-gray-500"
                }`}
              >
                {tab.label}
              </span>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
