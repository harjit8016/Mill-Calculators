import { useState } from "react";
import { InputField } from "./input-field";
import { MetricCard } from "./metric-card";
import { VerdictPill } from "./verdict-pill";
import { CTAButton } from "./cta-button";
import { SectionLabel } from "./section-label";

export function YieldCalculator() {
  const [billetWeight, setBilletWeight] = useState("1000");
  const [billetPrice, setBilletPrice] = useState("45");
  const [product, setProduct] = useState("TMT 10mm");
  const [actualOutput, setActualOutput] = useState("920");
  const [sellingPrice, setSellingPrice] = useState("52");

  // Calculations
  const yieldPercentage = (parseFloat(actualOutput) / parseFloat(billetWeight) * 100).toFixed(1);
  const lossKg = (parseFloat(billetWeight) - parseFloat(actualOutput)).toFixed(1);
  const lossRupees = (parseFloat(lossKg) * parseFloat(billetPrice)).toFixed(0);
  const revenue = (parseFloat(actualOutput) * parseFloat(sellingPrice)).toFixed(0);

  const getVerdictVariant = () => {
    const yieldNum = parseFloat(yieldPercentage);
    if (yieldNum >= 95) return "excellent";
    if (yieldNum >= 90) return "average";
    return "poor";
  };

  const getVerdictText = () => {
    const yieldNum = parseFloat(yieldPercentage);
    if (yieldNum >= 95) return "Excellent yield";
    if (yieldNum >= 90) return "Average yield";
    return "Poor yield";
  };

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-xl font-semibold">Billet to bar — yield calculator</h1>
        <p className="text-sm text-gray-400">Track yield loss and its cost per shift</p>
      </div>

      {/* Billet Input Section */}
      <div>
        <SectionLabel text="Billet Input" />
        <div className="grid grid-cols-2 gap-3">
          <InputField
            label="Billet weight"
            value={billetWeight}
            onChange={setBilletWeight}
            placeholder="1000"
            suffix="kg"
          />
          <InputField
            label="Billet price"
            value={billetPrice}
            onChange={setBilletPrice}
            placeholder="45"
            suffix="₹/kg"
          />
        </div>
      </div>

      {/* Finished Bar Output Section */}
      <div>
        <SectionLabel text="Finished Bar Output" />
        <div className="space-y-3">
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] uppercase tracking-wide text-gray-400">
              Product
            </label>
            <select
              value={product}
              onChange={(e) => setProduct(e.target.value)}
              className="w-full h-10 px-3 bg-[#2a2a2a] border border-gray-700 rounded-lg text-white outline-none focus:border-[#185FA5]"
            >
              <option>TMT 10mm</option>
              <option>TMT 12mm</option>
              <option>TMT 16mm</option>
              <option>TMT 20mm</option>
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <InputField
              label="Actual output"
              value={actualOutput}
              onChange={setActualOutput}
              placeholder="920"
              suffix="kg"
            />
            <InputField
              label="Selling price"
              value={sellingPrice}
              onChange={setSellingPrice}
              placeholder="52"
              suffix="₹/kg"
            />
          </div>
        </div>
      </div>

      {/* Divider */}
      <div className="border-t border-gray-700"></div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 gap-3">
        <MetricCard label="Yield %" value={`${yieldPercentage}%`} variant="green" />
        <MetricCard label="Loss kg" value={lossKg} variant="red" />
        <MetricCard label="Loss ₹" value={`₹${lossRupees}`} variant="red" />
        <MetricCard label="Revenue ₹" value={`₹${revenue}`} variant="green" />
      </div>

      {/* Progress Bar */}
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-gray-400">Yield</span>
          <span className="text-[#185FA5]">{yieldPercentage}%</span>
        </div>
        <div className="w-full h-2 bg-gray-800 rounded-full overflow-hidden">
          <div
            className="h-full bg-[#185FA5] transition-all"
            style={{ width: `${yieldPercentage}%` }}
          ></div>
        </div>
      </div>

      {/* Verdict */}
      <div className="space-y-2">
        <VerdictPill text={getVerdictText()} variant={getVerdictVariant()} />
        <p className="text-sm text-gray-400">
          {parseFloat(yieldPercentage) >= 95
            ? "Your yield is excellent. Keep up the good work!"
            : parseFloat(yieldPercentage) >= 90
            ? "Your yield is acceptable but there's room for improvement."
            : "Yield is below target. Check rolling parameters and billet quality."}
        </p>
      </div>

      {/* CTA Button */}
      <CTAButton text="How to improve yield" onClick={() => alert("Opening yield improvement guide...")} />
    </div>
  );
}
