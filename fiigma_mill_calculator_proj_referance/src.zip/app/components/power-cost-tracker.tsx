import { useState } from "react";
import { InputField } from "./input-field";
import { MetricCard } from "./metric-card";
import { VerdictPill } from "./verdict-pill";
import { CTAButton } from "./cta-button";
import { SectionLabel } from "./section-label";

interface ShiftData {
  name: string;
  unitsConsumed: string;
  tonnesProduced: string;
}

export function PowerCostTracker() {
  const [ratePerUnit, setRatePerUnit] = useState("6");
  const [targetUnitsPerTonne, setTargetUnitsPerTonne] = useState("450");
  const [avgTonnesPerShift, setAvgTonnesPerShift] = useState("15");

  const [shifts, setShifts] = useState<ShiftData[]>([
    { name: "Morning", unitsConsumed: "6500", tonnesProduced: "14" },
    { name: "Afternoon", unitsConsumed: "7200", tonnesProduced: "16" },
    { name: "Night", unitsConsumed: "6750", tonnesProduced: "15" },
  ]);

  const updateShift = (index: number, field: keyof ShiftData, value: string) => {
    const newShifts = [...shifts];
    newShifts[index] = { ...newShifts[index], [field]: value };
    setShifts(newShifts);
  };

  // Calculations
  const rate = parseFloat(ratePerUnit);
  const targetUnits = parseFloat(targetUnitsPerTonne);
  const targetCostPerTonne = rate * targetUnits;

  const shiftMetrics = shifts.map((shift) => {
    const units = parseFloat(shift.unitsConsumed) || 0;
    const tonnes = parseFloat(shift.tonnesProduced) || 0;
    const unitsPerTonne = tonnes > 0 ? units / tonnes : 0;
    const costPerTonne = unitsPerTonne * rate;
    const isOverTarget = unitsPerTonne > targetUnits;
    return { unitsPerTonne, costPerTonne, isOverTarget };
  });

  const totalUnits = shifts.reduce((sum, shift) => sum + (parseFloat(shift.unitsConsumed) || 0), 0);
  const totalTonnes = shifts.reduce((sum, shift) => sum + (parseFloat(shift.tonnesProduced) || 0), 0);
  const avgUnitsPerTonne = totalTonnes > 0 ? totalUnits / totalTonnes : 0;
  const avgCostPerTonne = avgUnitsPerTonne * rate;
  const totalPowerBill = totalUnits * rate;
  const extraCost = totalTonnes > 0 ? (avgUnitsPerTonne - targetUnits) * totalTonnes * rate : 0;

  const getVerdictVariant = () => {
    if (avgUnitsPerTonne <= targetUnits) return "on-target";
    if (avgUnitsPerTonne <= targetUnits * 1.05) return "average";
    return "poor";
  };

  const getVerdictText = () => {
    if (avgUnitsPerTonne <= targetUnits) return "On target";
    if (avgUnitsPerTonne <= targetUnits * 1.05) return "Slightly high";
    return "High consumption";
  };

  const maxUnitsPerTonne = Math.max(...shiftMetrics.map((m) => m.unitsPerTonne), targetUnits);

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-xl font-semibold">Power cost tracker</h1>
        <p className="text-sm text-gray-400">Track ₹/tonne across shifts — catch waste early</p>
      </div>

      {/* Input Section */}
      <div>
        <SectionLabel text="Input Parameters" />
        <div className="grid grid-cols-3 gap-3">
          <InputField
            label="₹ per unit"
            value={ratePerUnit}
            onChange={setRatePerUnit}
            placeholder="6"
          />
          <InputField
            label="Target units/tonne"
            value={targetUnitsPerTonne}
            onChange={setTargetUnitsPerTonne}
            placeholder="450"
          />
          <InputField
            label="Tonnes/shift avg"
            value={avgTonnesPerShift}
            onChange={setAvgTonnesPerShift}
            placeholder="15"
          />
        </div>
      </div>

      {/* Shift Log Table */}
      <div>
        <SectionLabel text="Shift Log" />
        <div className="bg-[#2a2a2a] rounded-lg overflow-hidden">
          {/* Header */}
          <div className="grid grid-cols-4 gap-2 px-3 py-2 bg-gray-800 border-b border-gray-700">
            <div className="text-[10px] uppercase tracking-wide text-gray-400">Shift</div>
            <div className="text-[10px] uppercase tracking-wide text-gray-400">Units</div>
            <div className="text-[10px] uppercase tracking-wide text-gray-400">Tonnes</div>
            <div className="text-[10px] uppercase tracking-wide text-gray-400">₹/tonne</div>
          </div>
          {/* Rows */}
          {shifts.map((shift, index) => {
            const metrics = shiftMetrics[index];
            return (
              <div key={index} className="grid grid-cols-4 gap-2 px-3 py-2 border-b border-gray-700 items-center">
                <div className="text-sm text-white">{shift.name}</div>
                <input
                  type="text"
                  value={shift.unitsConsumed}
                  onChange={(e) => updateShift(index, "unitsConsumed", e.target.value)}
                  className="h-8 px-2 bg-[#1a1a1a] border border-gray-700 rounded text-white text-sm outline-none focus:border-[#185FA5]"
                />
                <input
                  type="text"
                  value={shift.tonnesProduced}
                  onChange={(e) => updateShift(index, "tonnesProduced", e.target.value)}
                  className="h-8 px-2 bg-[#1a1a1a] border border-gray-700 rounded text-white text-sm outline-none focus:border-[#185FA5]"
                />
                <div
                  className={`text-sm font-semibold ${
                    metrics.isOverTarget ? "text-[#8b1538]" : "text-[#2d5016]"
                  }`}
                >
                  ₹{metrics.costPerTonne.toFixed(0)}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Divider */}
      <div className="border-t border-gray-700"></div>

      {/* Summary Metrics */}
      <div className="grid grid-cols-2 gap-3">
        <MetricCard
          label="Avg units/tonne"
          value={avgUnitsPerTonne.toFixed(0)}
          variant="blue"
        />
        <MetricCard
          label="Avg ₹/tonne"
          value={`₹${avgCostPerTonne.toFixed(0)}`}
          variant={avgUnitsPerTonne <= targetUnits ? "green" : "red"}
        />
        <MetricCard
          label="Total units today"
          value={totalUnits.toFixed(0)}
          variant="blue"
        />
        <MetricCard
          label="Total power bill ₹"
          value={`₹${totalPowerBill.toFixed(0)}`}
          variant="blue"
        />
      </div>

      {/* Bar Chart */}
      <div className="space-y-3">
        <SectionLabel text="Shift Comparison" />
        <div className="space-y-2">
          {shifts.map((shift, index) => {
            const metrics = shiftMetrics[index];
            const percentage = (metrics.unitsPerTonne / maxUnitsPerTonne) * 100;
            return (
              <div key={index} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400">{shift.name}</span>
                  <span className={metrics.isOverTarget ? "text-[#8b1538]" : "text-[#185FA5]"}>
                    {metrics.unitsPerTonne.toFixed(0)} units/t
                  </span>
                </div>
                <div className="relative w-full h-6 bg-gray-800 rounded overflow-hidden">
                  <div
                    className={`h-full transition-all ${
                      metrics.isOverTarget ? "bg-[#8b1538]" : "bg-[#185FA5]"
                    }`}
                    style={{ width: `${percentage}%` }}
                  ></div>
                  {/* Target line */}
                  <div
                    className="absolute top-0 bottom-0 w-0.5 bg-[#2d5016]"
                    style={{
                      left: `${(targetUnits / maxUnitsPerTonne) * 100}%`,
                    }}
                  ></div>
                </div>
              </div>
            );
          })}
          {/* Legend */}
          <div className="flex items-center gap-2 text-xs text-gray-400 mt-2">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 bg-[#2d5016] rounded-sm"></div>
              <span>Target ({targetUnits} units/t)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Extra Cost Callout */}
      {extraCost > 0 && (
        <div className="bg-[#FAEEDA] rounded-lg p-4">
          <div className="text-sm text-[#8b6914] font-semibold">
            Extra cost vs target: ₹{extraCost.toFixed(0)}
          </div>
          <div className="text-xs text-[#8b6914] opacity-70 mt-1">
            You're consuming {(avgUnitsPerTonne - targetUnits).toFixed(0)} extra units per tonne
          </div>
        </div>
      )}

      {/* Verdict */}
      <div className="space-y-2">
        <VerdictPill text={getVerdictText()} variant={getVerdictVariant()} />
        <p className="text-sm text-gray-400">
          {avgUnitsPerTonne <= targetUnits
            ? "Excellent! All shifts are meeting or beating the target."
            : avgUnitsPerTonne <= targetUnits * 1.05
            ? "Consumption is slightly high. Check furnace efficiency."
            : "High power consumption detected. Investigate equipment and processes."}
        </p>
      </div>

      {/* CTA Buttons */}
      <div className="space-y-3">
        <CTAButton text="View weekly trend" onClick={() => alert("Opening weekly trend...")} />
        <CTAButton text="Download shift report" onClick={() => alert("Downloading report...")} />
      </div>
    </div>
  );
}
