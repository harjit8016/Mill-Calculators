import { ArrowRight } from "lucide-react";

interface CTAButtonProps {
  text: string;
  onClick?: () => void;
}

export function CTAButton({ text, onClick }: CTAButtonProps) {
  return (
    <button
      onClick={onClick}
      className="w-full h-[42px] border border-gray-600 rounded-lg text-white flex items-center justify-center gap-2 hover:bg-gray-800 transition-colors"
    >
      {text}
      <ArrowRight className="w-4 h-4" />
    </button>
  );
}
