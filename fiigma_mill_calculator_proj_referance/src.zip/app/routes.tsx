import { createBrowserRouter } from "react-router";
import { Layout } from "./components/layout";
import { YieldCalculator } from "./components/yield-calculator";
import { BreakevenCalculator } from "./components/breakeven-calculator";
import { PowerCostTracker } from "./components/power-cost-tracker";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: YieldCalculator },
      { path: "breakeven", Component: BreakevenCalculator },
      { path: "power", Component: PowerCostTracker },
    ],
  },
]);
